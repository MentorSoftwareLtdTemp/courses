//before returning its module definition.
//should require module4